from future.standard_library import install_aliases

install_aliases()

class DNSPythonBase:
    pass
