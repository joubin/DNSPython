from distutils.core import setup

setup(
    name='dnspython-lookup',
    version='0.1.0',
    author='Joubin Jabbari',
    author_email='joubin.j@gmail.com',
    packages=['dnspython'],
    url='http://pypi.python.org/pypi/TowelStuff/',
    license='LICENSE.txt',
    description='Check dns entries across the world',
    long_description=open('README.txt').read(),
    install_requires=[],
)
